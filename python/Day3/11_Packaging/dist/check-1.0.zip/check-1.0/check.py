def show(message, border="-"):
    line = border * len(message)
    print(line)
    print(message)
    print(line)
