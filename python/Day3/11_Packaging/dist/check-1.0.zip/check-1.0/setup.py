from distutils.core import setup

setup(
    name='check',
    version='1.0',
    py_modules=['check'],

    # metadata
    author='Manish Sharma',
    author_email='manishvbn@gmail.com',
    description='Just for Fun',
    license='Public domain',
    keywords='example'
)